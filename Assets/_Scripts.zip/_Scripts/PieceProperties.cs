// _Scripts/PieceProperties.cs
using UnityEngine;

// Este componente atua como um marcador para identificar GameObjects que são peças de operadores.
public class PieceProperties : MonoBehaviour
{
    // Por enquanto, este script pode ficar vazio.
    // Sua presença no GameObject já é o suficiente para o sistema de Raycast funcionar.
}