// _Scripts/CardType.cs
public enum CardType
{
    Action,
    Utility,
    Aura,
    Skill,
    Strategy,
    Freelancer,
    Effect,
    Energy
}