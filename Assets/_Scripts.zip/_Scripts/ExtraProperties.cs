using UnityEngine;

// Este componente é usado para marcar objetos de decoração ("Extras") na cena,
// permitindo que o MapEditor os identifique e salve suas propriedades.
public class ExtraProperties : MonoBehaviour
{
    // Por enquanto, este script pode ficar vazio.
    // Sua simples presença já é suficiente para a identificação.
}