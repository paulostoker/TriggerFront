// _Scripts/MapLayout.cs
using System.Collections.Generic;

[System.Serializable]
public class MapLayout
{
    public List<string> layout;
}